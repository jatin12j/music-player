
import Playlist from "../models/playlistModel.js";

const createPlaylist = async (req, res) => {
    try {
        const { name, desc } = req.body;
        const userId = req.user._id;

        if (!name) {
            return res.status(400).json({ message: "Playlist name is required" });
        }

        const newPlaylist = new Playlist({
            name,
            desc,
            user: userId,
            songs: [],
        });

        await newPlaylist.save();
        res.status(201).json(newPlaylist);
    } catch (error) {
        console.error("createPlaylist error", error);
        res.status(500).json({ message: "Failed to create playlist" });
    }
};

const getUserPlaylists = async (req, res) => {
    try {
        const userId = req.user._id;
        const playlists = await Playlist.find({ user: userId }).sort({ createdAt: -1 });
        res.status(200).json(playlists);
    } catch (error) {
        console.error("getUserPlaylists error", error);
        res.status(500).json({ message: "Failed to fetch playlists" });
    }
};

const addSongToPlaylist = async (req, res) => {
    try {
        const { playlistId } = req.params;
        const { song } = req.body;
        const userId = req.user._id;

        const playlist = await Playlist.findOne({ _id: playlistId, user: userId });

        if (!playlist) {
            return res.status(404).json({ message: "Playlist not found" });
        }

        // Check if song already exists in playlist
        const songExists = playlist.songs.some((s) => String(s.id) === String(song.id));

        if (songExists) {
            return res.status(400).json({ message: "Song already in playlist" });
        }

        playlist.songs.push(song);
        await playlist.save();

        res.status(200).json(playlist);
    } catch (error) {
        console.error("addSongToPlaylist error", error);
        res.status(500).json({ message: "Failed to add song to playlist" });
    }
};

const getPlaylistDetails = async (req, res) => {
    try {
        const { playlistId } = req.params;
        const userId = req.user._id;

        const playlist = await Playlist.findOne({ _id: playlistId, user: userId });

        if (!playlist) {
            return res.status(404).json({ message: "Playlist not found" });
        }

        res.status(200).json(playlist);
    } catch (error) {
        console.error("getPlaylistDetails error", error);
        res.status(500).json({ message: "Failed to fetch playlist details" });
    }
};

const deletePlaylist = async (req, res) => {
    try {
        const { playlistId } = req.params;
        const userId = req.user._id;

        const playlist = await Playlist.findOneAndDelete({ _id: playlistId, user: userId });

        if (!playlist) {
            return res.status(404).json({ message: "Playlist not found or not authorized" });
        }

        res.status(200).json({ message: "Playlist deleted successfully", id: playlistId });
    } catch (error) {
        console.error("deletePlaylist error", error);
        res.status(500).json({ message: "Failed to delete playlist" });
    }
};

export { createPlaylist, getUserPlaylists, addSongToPlaylist, getPlaylistDetails, deletePlaylist };
