import axios from "axios";

const getSongs = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit ?? "15", 10) || 15;
    const offset = parseInt(req.query.offset ?? "0", 10) || 0;

    const response = await axios.get(
      `https://api.jamendo.com/v3.0/tracks/?client_id=${process.env.JAMENDO_CLIENT_ID}&format=jsonpretty&limit=${limit}&offset=${offset}`
    );
    const data = response.data;
    res.status(200).json(data);
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ message: error.message });
  }
};

const getPlaylistByTag = async (req, res) => {
  try {
    const tag = (req.params.tag || req.query.tag || "").toString().trim();
    if (!tag)
      return res.status(400).json({ message: "Missing tag parameters" });

    const limit = parseInt(req.query.limit ?? "10", 10) || 10;
    const offset = parseInt(req.query.offset ?? "0", 10) || 0;
    const clientId = process.env.JAMENDO_CLIENT_ID;
    const params = {
      client_id: clientId,
      format: "jsonpretty",
      tags: tag,
      limit,
      offset,
    };

    const response = await axios.get("https://api.jamendo.com/v3.0/tracks/", {
      params,
    });

    return res.status(200).json(response.data);
  } catch (error) {
    console.error(
      "getPlaylistTag error",
      error?.response?.data ?? error.message ?? error
    );
    return res.status(500).json({ message: "Failed to fetch" });
  }
};

const toggleFavourite = async (req, res) => {
  try {
    const user = req.user;
    const song = req.body.song;

    const exists = user.favourites.find((fav) => String(fav.id) === String(song.id));

    if (exists) {
      user.favourites = user.favourites.filter((fav) => String(fav.id) !== String(song.id));
    } else {
      user.favourites.push(song);
    }

    await user.save();

    return res.status(200).json(user.favourites);
  } catch (error) {
    console.error(error.message);
    return res
      .status(400)
      .json({ message: "Favourites not added, something went wrong" });
  }
};

const searchSongs = async (req, res) => {
  try {
    const query = req.query.query;
    if (!query) return res.status(400).json({ message: "Missing query parameter" });

    const limit = parseInt(req.query.limit ?? "10", 10) || 10;
    const offset = parseInt(req.query.offset ?? "0", 10) || 0;
    const clientId = process.env.JAMENDO_CLIENT_ID;
    const params = {
      client_id: clientId,
      format: "jsonpretty",
      namesearch: query,
      limit,
      offset,
    };

    const response = await axios.get("https://api.jamendo.com/v3.0/tracks/", {
      params,
    });

    return res.status(200).json(response.data);
  } catch (error) {
    console.error(
      "searchSongs error",
      error?.response?.data ?? error.message ?? error
    );
    return res.status(500).json({ message: "Failed to search songs" });
  }
};

export { getSongs, getPlaylistByTag, toggleFavourite, searchSongs };
