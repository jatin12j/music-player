
import express from "express";
import { protect } from "../middleware/authMiddleware.js";
import {
    createPlaylist,
    getUserPlaylists,
    addSongToPlaylist,
    getPlaylistDetails,
    deletePlaylist,
} from "../controllers/playlistController.js";

const router = express.Router();

router.post("/create", protect, createPlaylist);
router.get("/user", protect, getUserPlaylists);
router.post("/:playlistId/add", protect, addSongToPlaylist);
router.get("/:playlistId", protect, getPlaylistDetails);
router.delete("/:playlistId", protect, deletePlaylist);

export default router;
