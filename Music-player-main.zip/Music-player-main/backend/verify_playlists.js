
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const BASE_URL = "http://localhost:5000/api";

const verifyPlaylists = async () => {
    try {
        console.log("Testing Playlists...");

        // 1. Register
        console.log("Registering new user...");
        const email = `testuser${Date.now()}@example.com`;
        const password = "password123";
        const name = "Test User";

        const registerRes = await axios.post(`${BASE_URL}/auth/signup`, {
            email,
            password,
            name
        });
        const token = registerRes.data.token;
        console.log(`Registered and logged in as ${email}.`);

        // 2. Create Playlist
        console.log("Creating playlist...");
        const playlistName = `Test Playlist ${Date.now()}`;
        const createRes = await axios.post(
            `${BASE_URL}/playlists/create`,
            { name: playlistName, desc: "Automated test playlist" },
            { headers: { Authorization: `Bearer ${token}` } }
        );
        const playlist = createRes.data;
        console.log(`Playlist created: ${playlist.name} (${playlist._id})`);

        // 3. Add Song to Playlist
        console.log("Adding song to playlist...");
        // Get a song first
        const songsRes = await axios.get(`${BASE_URL}/songs?limit=1`);
        const song = songsRes.data.results[0];

        // Transform song to correct format if needed (though backend handles it, let's be safe)
        const songData = {
            id: song.id,
            name: song.name,
            artist_name: song.artist_name,
            image: song.image,
            duration: song.duration,
            audio: song.audio,
        };

        const addRes = await axios.post(
            `${BASE_URL}/playlists/${playlist._id}/add`,
            { song: songData },
            { headers: { Authorization: `Bearer ${token}` } }
        );
        console.log("Song added.");

        // 4. Verify Song in Playlist
        console.log("Verifying song in playlist...");
        const detailsRes = await axios.get(
            `${BASE_URL}/playlists/${playlist._id}`,
            { headers: { Authorization: `Bearer ${token}` } }
        );

        const savedSongs = detailsRes.data.songs;
        const isSaved = savedSongs.some(s => String(s.id) === String(song.id));

        if (isSaved) {
            console.log("✅ Playlist verification passed: Song found in playlist.");
        } else {
            console.error("❌ Playlist verification failed: Song not found in playlist.");
        }

    } catch (error) {
        console.error("Verification failed:", error.response ? error.response.data : error.message);
    }
};

verifyPlaylists();
