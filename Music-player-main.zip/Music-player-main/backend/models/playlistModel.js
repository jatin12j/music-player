
import mongoose from "mongoose";

const playlistSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    desc: {
        type: String,
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true,
    },
    songs: [
        {
            id: { type: String, required: true },
            name: String,
            artist_name: String,
            image: String,
            duration: String,
            audio: String,
        },
    ],
}, { timestamps: true });

const Playlist = mongoose.model("Playlist", playlistSchema);
export default Playlist;
