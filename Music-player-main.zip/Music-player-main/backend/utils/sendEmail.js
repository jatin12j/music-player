import nodemailer from "nodemailer";

const sendMail = async (options) => {
  console.log("Preparing to send email via Mailtrap...");
  console.log("SMTP Config:", {
    host: process.env.MAILTRAP_HOST,
    port: process.env.MAILTRAP_PORT,
    user: process.env.MAILTRAP_USER,
    pass: process.env.MAILTRAP_PASS ? "****" : "MISSING",
  });

  const transporter = nodemailer.createTransport({
    host: process.env.MAILTRAP_HOST,
    port: process.env.MAILTRAP_PORT,
    auth: {
      user: process.env.MAILTRAP_USER,
      pass: process.env.MAILTRAP_PASS,
    },
  });

  const mailOptions = {
    from: "Synthesia <hello@synthesia.com>",
    to: options.to,
    subject: options.subject,
    html: options.html,
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent successfully!");
    console.log("Message ID:", info.messageId);
    console.log("Preview URL:", nodemailer.getTestMessageUrl(info)); // Sometimes available
  } catch (error) {
    console.error("Error sending email in sendMail utility:", error);
    throw error;
  }
};

export default sendMail;
