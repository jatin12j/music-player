
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const BASE_URL = "http://localhost:5000/api";

const verifyPagination = async () => {
    try {
        console.log("Testing Pagination...");

        // Fetch page 1
        console.log("Fetching page 1 (limit=5, offset=0)...");
        const res1 = await axios.get(`${BASE_URL}/songs?limit=5&offset=0`);
        const songs1 = res1.data.results;
        console.log(`Page 1 returned ${songs1.length} songs.`);

        // Fetch page 2
        console.log("Fetching page 2 (limit=5, offset=5)...");
        const res2 = await axios.get(`${BASE_URL}/songs?limit=5&offset=5`);
        const songs2 = res2.data.results;
        console.log(`Page 2 returned ${songs2.length} songs.`);

        // Verify different songs
        if (songs1[0].id !== songs2[0].id) {
            console.log("✅ Pagination verified: Page 1 and Page 2 contain different songs.");
        } else {
            console.error("❌ Pagination failed: Page 1 and Page 2 start with the same song.");
        }

    } catch (error) {
        console.error("Verification failed:", error.message);
    }
};

verifyPagination();
