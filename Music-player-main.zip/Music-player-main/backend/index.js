import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import connectDB from "./config/connectDB.js";
import authRoutes from "./routes/authRoutes.js"; // Renamed from 'router' to 'authRoutes' as per instruction's snippet
import songRoutes from "./routes/songRoutes.js"; // Renamed from 'songRouter' to 'songRoutes' as per instruction's snippet
import playlistRoutes from "./routes/playlistRoutes.js";

dotenv.config(".env");
const PORT = process.env.PORT || 5001;

const app = express();
app.use(express.json({ limit: "10mb" }));

//connect your database
connectDB();

app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  }),
);

app.get("/", (req, res) => {
  res.send("API is running");
});

app.use("/api/songs", songRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/playlists", playlistRoutes);

app.listen(PORT, () => console.log(`Server is running on Port ${PORT}`));
