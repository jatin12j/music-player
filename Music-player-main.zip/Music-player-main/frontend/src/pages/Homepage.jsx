import React, { useEffect, useState } from "react";
import { deletePlaylist } from "../redux/slices/playlistSlice";

import Footer from "../components/layout/Footer";
import SideMenu from "../components/layout/SideMenu";
import MainArea from "../components/layout/MainArea";

import "../css/pages/HomePage.css";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import useAudioPlayer from "../hooks/useAudioPlayer";
import Modal from "../components/common/Modal";
import EditProfile from "../components/auth/EditProfile";
import CreatePlaylistModal from "../components/common/CreatePlaylistModal";
import AddToPlaylistModal from "../components/common/AddToPlaylistModal";
import ThemeModal from "../components/common/ThemeModal";

const Homepage = () => {
  const dispatch = useDispatch();
  const [view, setView] = useState("home");
  const [songs, setSongs] = useState([]);
  const [searchSongs, setSearchSongs] = useState([]);
  const [openEditProfile, setOpenEditProfile] = useState(false);
  const [openCreatePlaylist, setOpenCreatePlaylist] = useState(false);
  const [openAddToPlaylist, setOpenAddToPlaylist] = useState(false);
  const auth = useSelector((state) => state.auth);
  const { themeModalOpen } = useSelector((state) => state.ui);

  const songsToDisplay = view === "search" ? searchSongs : songs;

  const {
    audioRef,
    currentIndex,
    currentSong,
    isPlaying,
    currentTime,
    duration,
    isMuted,
    loopEnabled,
    shuffleEnabled,
    playbackSpeed,
    volume,
    playSongAtIndex,
    handleTogglePlay,
    handleNext,
    handlePrev,
    handleTimeUpdate,
    handleLoadedMetadata,
    handleEnded,
    handleToggleMute,
    handleToggleLoop,
    handleToggleShuffle,
    handleChangeSpeed,
    handleSeek,
    handleChangeVolume,
  } = useAudioPlayer(songsToDisplay);

  const playerState = {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    isMuted,
    loopEnabled,
    shuffleEnabled,
    playbackSpeed,
    volume,
  };

  const playerControls = {
    playSongAtIndex,
    handleTogglePlay,
    handleNext,
    handlePrev,
    handleSeek,
    onOpenAddToPlaylist: () => setOpenAddToPlaylist(true),
  };

  const playerFeatures = {
    onToggleMute: handleToggleMute,
    onToggleLoop: handleToggleLoop,
    onToggleShuffle: handleToggleShuffle,
    onChangeSpeed: handleChangeSpeed,
    onChangeVolume: handleChangeVolume,
  };

  const fetchInitialSongs = async () => {
    try {
      const res = await axios.get(
        `${import.meta.env.VITE_BASE_URL}/api/songs?limit=15&offset=0`,
      );
      setSongs(res.data.results || []);
      setOffset(0); // Reset offset when fetching initial songs
      setHasMore(true); // Reset hasMore
    } catch (error) {
      console.error("Error while fetching the songs", error);
      setSongs([]);
    }
  };

  useEffect(() => {
    fetchInitialSongs();
  }, []);

  const [selectedTag, setSelectedTag] = useState("");
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const loadMoreSongs = async () => {
    try {
      const limit = 15;
      const newOffset = offset + limit;
      let url = `${import.meta.env.VITE_BASE_URL}/api/songs?limit=${limit}&offset=${newOffset}`;

      if (view === "search" && searchSongs.length > 0) {
        // Search pagination is handled differently or needs search term
        // For now, let's focus on home/playlist pagination
        // If we tracked the last search query, we could paginate search too
        return;
      } else if (selectedTag) {
        url = `${import.meta.env.VITE_BASE_URL}/api/songs/playlistByTag/${selectedTag}?limit=${limit}&offset=${newOffset}`;
      }

      const res = await axios.get(url);
      const newSongs = res.data.results || [];

      if (newSongs.length === 0) {
        setHasMore(false);
      } else {
        setSongs((prevSongs) => [...prevSongs, ...newSongs]);
        setOffset(newOffset);
      }
    } catch (error) {
      console.error("Failed to load more songs", error);
    }
  };

  const handlePlaylistSelect = async (playlistId) => {
    try {
      setSelectedTag("");
      setOffset(0);
      setHasMore(false); // Playlists don't have pagination yet

      const { token } = auth;
      const res = await axios.get(
        `${import.meta.env.VITE_BASE_URL}/api/playlists/${playlistId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setSongs(res.data.songs || []);
    } catch (error) {
      console.error("Failed to load playlist", error);
      setSongs([]);
    }
  };

  const loadPlaylist = async (tag) => {
    if (!tag) {
      console.warn("No tag is provided");
      return;
    }

    try {
      setSelectedTag(tag); // Set selected tag
      setOffset(0);
      setHasMore(true);
      const res = await axios.get(
        `${import.meta.env.VITE_BASE_URL}/api/songs/playlistByTag/${tag}?limit=15&offset=0`,
      );

      setSongs(res.data.results || []);
    } catch (error) {
      console.error("Failed to load playlist", error);
      setSongs([]);
    }
  };

  // When user clicks on a song in a table
  const handleSelectSong = (index) => {
    playSongAtIndex(index);
  };

  const handlePlayFavourite = (song) => {
    const favourites = auth?.user?.favourites || [];
    if (!favourites.length) return;

    const index = auth?.user?.favourites.findIndex((fav) => fav.id === song.id);
    setSongs(auth?.user?.favourites);
    setView("home");
    setSelectedTag(""); // Clear selection when playing favourites

    setTimeout(() => {
      if (index != -1) {
        playSongAtIndex(index);
      }
    }, 0);
  };

  return (
    <div className="homepage-root">
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleEnded}
      >
        {currentSong && <source src={currentSong.audio} type="audio/mpeg" />}
      </audio>
      <div className="homepage-main-wrapper">
        {/* Sidebar */}
        <div className="homepage-sidebar">
          <SideMenu
            setView={(newView) => {
              setView(newView);
              if (newView === "home") {
                setSelectedTag("");
                fetchInitialSongs();
              } else {
                setSelectedTag(""); // Clear tag on view change to other views too if needed
              }
            }}
            view={view}
            onOpenEditProfile={() => setOpenEditProfile(true)}
            onCreatePlaylist={() => setOpenCreatePlaylist(true)}
            onSelectPlaylist={handlePlaylistSelect}
            onDeletePlaylist={(id) => dispatch(deletePlaylist(id))}
          />
        </div>
        {/* Main Content */}
        <div className="homepage-content">
          <MainArea
            view={view}
            currentIndex={currentIndex}
            onSelectSong={handleSelectSong}
            onSelectFavourite={handlePlayFavourite}
            onSelectTag={loadPlaylist}
            selectedTag={selectedTag} // Pass selectedTag
            songsToDisplay={songsToDisplay}
            setSearchSongs={setSearchSongs}
            loadMoreSongs={loadMoreSongs}
            hasMore={hasMore}
            songs={songs}
          />
        </div>
      </div>
      {/* Footer Player */}
      <Footer
        playerState={playerState}
        playerControls={playerControls}
        playerFeatures={playerFeatures}
      />

      {openEditProfile && (
        <Modal onClose={() => setOpenEditProfile(false)}>
          <EditProfile onClose={() => setOpenEditProfile(false)} />
        </Modal>
      )}

      {openCreatePlaylist && (
        <CreatePlaylistModal onClose={() => setOpenCreatePlaylist(false)} />
      )}

      {openAddToPlaylist && currentSong && (
        <AddToPlaylistModal
          onClose={() => setOpenAddToPlaylist(false)}
          song={currentSong}
        />
      )}

      {themeModalOpen && <ThemeModal />}
    </div>
  );
};

export default Homepage;
