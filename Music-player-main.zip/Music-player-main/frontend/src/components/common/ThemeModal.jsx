import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setTheme, closeThemeModal } from "../../redux/slices/uiSlice";
import { IoMdClose } from "react-icons/io";

const themes = [
    { id: "dark", name: "Dark", color: "from-gray-900 via-black to-gray-900" },
    { id: "ocean", name: "Ocean", color: "from-blue-900 via-slate-900 to-cyan-900" },
    { id: "sunset", name: "Sunset", color: "from-purple-900 via-gray-900 to-pink-900" },
    { id: "forest", name: "Forest", color: "from-green-900 via-slate-900 to-emerald-900" },
];

const ThemeModal = () => {
    const dispatch = useDispatch();
    const { theme } = useSelector((state) => state.ui);

    console.log("ThemeModal rendering");

    const handleThemeSelect = (themeId) => {
        dispatch(setTheme(themeId));
    };

    return (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
            <div className="bg-gray-900/90 border border-white/10 p-6 rounded-2xl w-80 shadow-2xl relative">
                <button
                    onClick={() => dispatch(closeThemeModal())}
                    className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors"
                >
                    <IoMdClose size={24} />
                </button>

                <h2 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent mb-6">
                    Select Theme
                </h2>

                <div className="grid grid-cols-2 gap-4">
                    {themes.map((t) => (
                        <button
                            key={t.id}
                            onClick={() => handleThemeSelect(t.id)}
                            className={`relative p-4 rounded-xl border-2 transition-all duration-300 group overflow-hidden ${theme === t.id
                                ? "border-purple-500 shadow-lg shadow-purple-500/20"
                                : "border-gray-700 hover:border-gray-500"
                                }`}
                        >
                            <div className={`absolute inset-0 bg-gradient-to-br ${t.color} opacity-80`} />

                            <span className="relative z-10 font-medium text-white shadow-black drop-shadow-md">
                                {t.name}
                            </span>

                            {theme === t.id && (
                                <div className="absolute top-2 right-2 w-2 h-2 bg-purple-500 rounded-full shadow-[0_0_8px_rgba(168,85,247,0.8)]" />
                            )}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ThemeModal;
