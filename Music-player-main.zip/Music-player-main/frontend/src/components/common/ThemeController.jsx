import React, { useEffect } from "react";
import { useSelector } from "react-redux";

const ThemeController = () => {
    const { theme } = useSelector((state) => state.ui);

    useEffect(() => {
        document.body.className = `theme-${theme}`;
    }, [theme]);

    // This component doesn't render anything, it just manages the side effect
    return null;
};

export default ThemeController;
