
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { createPlaylist } from "../../redux/slices/playlistSlice";
import toast from "react-hot-toast";

const CreatePlaylistModal = ({ onClose }) => {
    const [name, setName] = useState("");
    const [desc, setDesc] = useState("");
    const dispatch = useDispatch();

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!name.trim()) return;

        try {
            await dispatch(createPlaylist({ name, desc })).unwrap();
            toast.success("Playlist created successfully!");
            onClose();
        } catch (error) {
            console.error("Failed to create playlist", error);
            toast.error("Failed to create playlist");
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
            <div className="bg-gray-900 p-6 rounded-lg w-96 border border-purple-500">
                <h2 className="text-xl font-bold text-white mb-4">Create New Playlist</h2>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label className="block text-gray-400 mb-2">Name</label>
                        <input
                            type="text"
                            className="w-full bg-gray-800 text-white p-2 rounded border border-gray-700 focus:border-purple-500 outline-none"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="My Awesome Playlist"
                            autoFocus
                        />
                    </div>
                    <div className="mb-6">
                        <label className="block text-gray-400 mb-2">Description (Optional)</label>
                        <textarea
                            className="w-full bg-gray-800 text-white p-2 rounded border border-gray-700 focus:border-purple-500 outline-none resize-none"
                            rows="3"
                            value={desc}
                            onChange={(e) => setDesc(e.target.value)}
                            placeholder="Chill vibes only..."
                        />
                    </div>
                    <div className="flex justify-end gap-3">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded font-medium transition-colors"
                        >
                            Create
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreatePlaylistModal;
