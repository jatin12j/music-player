
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchPlaylists, addSongToPlaylist } from "../../redux/slices/playlistSlice";
import { MdPlaylistPlay } from "react-icons/md";
import toast from "react-hot-toast";

const AddToPlaylistModal = ({ onClose, song }) => {
    const dispatch = useDispatch();
    const { playlists } = useSelector((state) => state.playlists);

    useEffect(() => {
        dispatch(fetchPlaylists());
    }, [dispatch]);

    const handlePlaylistClick = async (playlistId) => {
        try {
            if (!song) return;

            const songData = {
                id: song.id,
                name: song.name,
                artist_name: song.artist_name || song.artist?.name,
                image: song.image,
                duration: song.duration,
                audio: song.audio,
            };

            await dispatch(addSongToPlaylist({ playlistId, song: songData })).unwrap();
            toast.success("Song added to playlist!");
            onClose();
        } catch (error) {
            console.error("Failed to add song", error);
            toast.error(error || "Failed to add song to playlist");
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
            <div className="bg-gray-900 p-6 rounded-lg w-80 border border-purple-500">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold text-white">Add to Playlist</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white">
                        ✕
                    </button>
                </div>

                <ul className="max-h-60 overflow-y-auto">
                    {playlists.length === 0 ? (
                        <p className="text-gray-400 text-center py-4">No playlists found. Create one first!</p>
                    ) : (
                        playlists.map((playlist) => (
                            <li key={playlist._id} className="mb-2">
                                <button
                                    onClick={() => handlePlaylistClick(playlist._id)}
                                    className="w-full flex items-center p-3 rounded bg-gray-800 hover:bg-gray-700 transition-colors text-left"
                                >
                                    <MdPlaylistPlay className="text-purple-500 mr-3" size={20} />
                                    <span className="text-white truncate">{playlist.name}</span>
                                </button>
                            </li>
                        ))
                    )}
                </ul>
            </div>
        </div>
    );
};

export default AddToPlaylistModal;
