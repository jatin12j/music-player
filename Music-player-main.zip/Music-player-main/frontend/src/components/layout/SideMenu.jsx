import React from "react";

import { IoIosSettings } from "react-icons/io";
import logo from "../../assets/wsa-logo.jpg";
import "../../css/sidemenu/SideMenu.css";
import { CiUser } from "react-icons/ci";
import { AiOutlineHome, AiOutlineSearch, AiOutlineHeart } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import { openAuthModal, openThemeModal } from "../../redux/slices/uiSlice";
import { fetchPlaylists } from "../../redux/slices/playlistSlice";
import { MdPlaylistPlay, MdAdd, MdDelete, MdColorLens } from "react-icons/md";
import { useEffect } from "react";

const SideMenu = ({ setView, view, onOpenEditProfile, onCreatePlaylist, onSelectPlaylist, onDeletePlaylist }) => {
  const dispatch = useDispatch();
  const { user, isAuthenticated } = useSelector((state) => state.auth);
  const { playlists } = useSelector((state) => state.playlists);

  useEffect(() => {
    if (isAuthenticated) {
      dispatch(fetchPlaylists());
    }
  }, [dispatch, isAuthenticated]);

  const displayUser = {
    name: user?.name || "Guest",
    avatar: user?.avatar || "",
  };

  const handleSearchClick = () => {
    if (!isAuthenticated) {
      dispatch(openAuthModal("login"));
      return;
    }
    setView("search");
  };

  const handleFavouriteClick = () => {
    if (!isAuthenticated) {
      dispatch(openAuthModal("login"));
      return;
    }
    setView("favourite");
  };

  const getNavBtnClass = (item) =>
    `sidemenu-nav-btn ${view === item ? "active" : ""}`;
  return (
    <>
      <aside className="sidemenu-root">
        {/* Logo */}
        <div className="sidemenu-header">
          <img src={logo} alt="wsa-logo" className="sidemenu-logo-img" />
          <h2 className="sidemenu-logo-title">Synthesia</h2>
        </div>
        {/* Navigation */}
        <nav className="sidemenu-nav" aria-label="Main navigation">
          <ul className="sidemenu-nav-list">
            <li>
              <button
                className={getNavBtnClass("home")}
                onClick={() => setView("home")}
              >
                <AiOutlineHome className="sidemenu-nav-icon" size={18} />
                <span>Home</span>
              </button>
            </li>
            <li>
              <button
                onClick={handleSearchClick}
                className={getNavBtnClass("search")}
              >
                <AiOutlineSearch className="sidemenu-nav-icon" size={18} />
                <span> Search</span>
              </button>
            </li>
            <li>
              <button
                className={getNavBtnClass("favourite")}
                onClick={handleFavouriteClick}
              >
                <AiOutlineHeart size={18} />
                <span>Favourite</span>
              </button>
            </li>
          </ul>
        </nav>

        {isAuthenticated && (
          <div className="sidemenu-playlists">
            <div className="flex items-center justify-between px-6 py-2">
              <h3 className="text-gray-400 text-xs font-semibold uppercase tracking-wider">
                Your Playlists
              </h3>
              <button
                onClick={onCreatePlaylist}
                className="text-gray-400 hover:text-white transition-colors"
                title="Create Playlist"
              >
                <MdAdd size={20} />
              </button>
            </div>
            <ul className="sidemenu-nav-list">
              {playlists.map((playlist) => (
                <li key={playlist._id} className="flex items-center group relative">
                  <button
                    className={`sidemenu-nav-btn ${view === `playlist-${playlist._id}` ? "active" : ""}`}
                    onClick={() => {
                      setView(`playlist-${playlist._id}`);
                      onSelectPlaylist(playlist._id);
                    }}
                  >
                    <MdPlaylistPlay className="sidemenu-nav-icon" size={18} />
                    <span className="truncate">{playlist.name}</span>
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (window.confirm("Are you sure you want to delete this playlist?")) {
                        onDeletePlaylist(playlist._id);
                      }
                    }}
                    className="absolute right-2 opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 transition-all p-2 z-20"
                    title="Delete Playlist"
                  >
                    <MdDelete size={16} />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex-1"></div>
        <div className="sidemenu-profile-row">
          {displayUser.avatar ? (
            <img
              src={displayUser.avatar}
              alt="profile"
              className="sidemenu-avatar-img"
            />
          ) : (
            <div className="profile-placeholder">
              <CiUser size={30} />
            </div>
          )}

          <div className="sidemenu-username-wrapper">
            <div className="sidemenu-username">{displayUser.name}</div>
          </div>
          {isAuthenticated && (
            <div className="settings-container">
              <button
                type="button"
                className="sidemenu-settings-btn"
                onClick={onOpenEditProfile}
              >
                <IoIosSettings size={20} />
              </button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};

export default SideMenu;
