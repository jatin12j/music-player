import React from "react";

import Auth from "../auth/Auth";
import Playlist from "../player/Playlist";
import SearchBar from "../search/SearchBar";
import SongList from "../player/SongList";
import SongGrid from "../songs/SongGrid";

import "../../css/mainArea/MainArea.css";
import { useSelector } from "react-redux";

const MainArea = ({
  view,
  currentIndex,
  onSelectSong,
  onSelectFavourite,
  onSelectTag,
  selectedTag,
  songsToDisplay,
  setSearchSongs,
  loadMoreSongs,
  hasMore,
  songs,
}) => {
  const auth = useSelector((state) => state.auth);

  return (
    <div className="mainarea-root">
      <div className="mainarea-top">
        <Auth />
        {(view === "home" || view.startsWith("playlist-")) && (
          <Playlist onSelectTag={onSelectTag} selectedTag={selectedTag} />
        )}
        {view === "search" && (
          <SearchBar setSearchSongs={setSearchSongs} songs={songs} />
        )}
      </div>

      <div className="mainarea-scroll">
        {(view === "home" ||
          view === "search" ||
          view.startsWith("playlist-")) && (
            <SongList
              songs={songsToDisplay}
              onSelectSong={onSelectSong}
              currentIndex={currentIndex}
            />
          )}

        {view === "home" && hasMore && (
          <div className="flex justify-center py-6 pb-20">
            <button
              onClick={loadMoreSongs}
              className="px-6 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-full font-medium transition-colors"
            >
              Load More
            </button>
          </div>
        )}

        {view === "favourite" && (
          <SongGrid
            songs={auth?.user?.favourites || []}
            onSelectFavourite={onSelectFavourite}
          />
        )}
      </div>
    </div>
  );
};

export default MainArea;
