import React, { useState } from "react";
import "../../css/songs/SongGrid.css";
import SongCard from "./SongCard";

const SongGrid = ({ songs, onSelectFavourite }) => {
  const [searchTerm, setSearchTerm] = useState("");

  if (!songs || songs.length === 0) {
    return (
      <div className="song-grid-empty">
        <p className="empty-text">No favourite songs yet</p>
        <p className="empty-subtext">
          Start exploring and add songs to your favourites!
        </p>
      </div>
    );
  }

  const filteredSongs = songs.filter((song) => {
    const name = song.name?.toLowerCase() || "";
    // Handle both artist_name (DB) and artist.name (API) formats
    const artist = (song.artist_name || song.artist?.name || "").toLowerCase();
    const term = searchTerm.toLowerCase();
    return name.includes(term) || artist.includes(term);
  });

  return (
    <div className="songs-grid-wrapper">
      <div className="song-grid-header">
        <h2 className="song-grid-heading">Your favourites</h2>
        <input
          type="text"
          placeholder="Search in favourites..."
          className="song-grid-search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {filteredSongs.length === 0 ? (
        <div className="song-grid-empty">
          <p className="empty-text">No matches found</p>
        </div>
      ) : (
        <div className="song-grid">
          {filteredSongs.map((song) => (
            <SongCard
              key={song.id}
              song={song}
              onSelectFavourite={() => onSelectFavourite(song)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default SongGrid;
