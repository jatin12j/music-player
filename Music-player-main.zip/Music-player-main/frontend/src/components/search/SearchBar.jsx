import axios from "axios";
import React, { useEffect, useState } from "react";
import { CiSearch } from "react-icons/ci";
import "../../css/search/SearchBar.css";

const SearchBar = ({ setSearchSongs, songs }) => {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query.trim()) {
      setSearchSongs([]);
      return;
    }

    const fetchSongs = async () => {
      try {
        setLoading(true);

        if (songs && songs.length > 0) {
          // Local filtering
          const term = query.toLowerCase();
          const filtered = songs.filter((song) => {
            const name = song.name?.toLowerCase() || "";
            const artist = (
              song.artist_name ||
              song.artist?.name ||
              ""
            ).toLowerCase();
            return name.includes(term) || artist.includes(term);
          });
          setSearchSongs(filtered);
          // Simulate network delay for UX or just instant? Instant is better.
          setLoading(false);
          return;
        }

        // Fallback to API/Jamendo search if no songs provided (though in this case they are)
        const res = await axios.get(
          `${import.meta.env.VITE_BASE_URL}/api/songs/search`,
          {
            params: {
              query: query,
            },
          },
        );

        setSearchSongs(res.data.results);
      } catch (error) {
        console.error("Search failed", error);
        setSearchSongs([]);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(fetchSongs, 400);

    return () => clearInterval(debounce);
  }, [query, setSearchSongs, songs]);

  return (
    <div className="searchbar-root">
      <div className="searchbar-input-wrapper">
        <input
          className="searchbar-input"
          type="text"
          placeholder="Search songs..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
        />
        <CiSearch className="searchbar-icon" size={20} />
      </div>
      {!query && !loading && (
        <p className="searchbar-empty">Search songs to display</p>
      )}
      {loading && <p className="searchbar-loading">Searching...</p>}
    </div>
  );
};

export default SearchBar;
