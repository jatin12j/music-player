import { createSlice } from "@reduxjs/toolkit";

const uiSlice = createSlice({
  name: "ui",
  initialState: {
    authModalOpen: false,
    authMode: "login", //login/signup/forgot
    theme: "dark",
    themeModalOpen: false,
  },
  reducers: {
    openAuthModal: (state, action) => {
      state.authModalOpen = true;
      state.authMode = action.payload || "login";
    },

    closeAuthModal: (state, action) => {
      state.authModalOpen = false;
      state.authMode = "login";
    },

    switchAuthMode: (state, action) => {
      state.authMode = action.payload;
    },

    setTheme: (state, action) => {
      state.theme = action.payload;
    },

    openThemeModal: (state) => {
      state.themeModalOpen = true;
    },

    closeThemeModal: (state) => {
      state.themeModalOpen = false;
    },
  },
});

export const {
  openAuthModal,
  closeAuthModal,
  switchAuthMode,
  setTheme,
  openThemeModal,
  closeThemeModal,
} = uiSlice.actions;

export default uiSlice.reducer;
