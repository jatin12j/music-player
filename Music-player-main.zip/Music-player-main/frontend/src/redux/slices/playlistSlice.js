
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const initialState = {
    playlists: [],
    currentPlaylist: null,
    isLoading: false,
    error: null,
};

// Async thunk to fetch user playlists
export const fetchPlaylists = createAsyncThunk(
    "playlists/fetchUserPlaylists",
    async (_, { getState, rejectWithValue }) => {
        try {
            const { token } = getState().auth;
            const config = {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            };
            const res = await axios.get(
                `${import.meta.env.VITE_BASE_URL}/api/playlists/user`,
                config
            );
            return res.data;
        } catch (error) {
            return rejectWithValue(
                error.response && error.response.data.message
                    ? error.response.data.message
                    : error.message
            );
        }
    }
);

// Async thunk to create a playlist
export const createPlaylist = createAsyncThunk(
    "playlists/createPlaylist",
    async (playlistData, { getState, rejectWithValue }) => {
        try {
            const { token } = getState().auth;
            const config = {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            };
            const res = await axios.post(
                `${import.meta.env.VITE_BASE_URL}/api/playlists/create`,
                playlistData,
                config
            );
            return res.data;
        } catch (error) {
            return rejectWithValue(
                error.response && error.response.data.message
                    ? error.response.data.message
                    : error.message
            );
        }
    }
);

// Async thunk to add song to playlist
export const addSongToPlaylist = createAsyncThunk(
    "playlists/addSong",
    async ({ playlistId, song }, { getState, rejectWithValue }) => {
        try {
            const { token } = getState().auth;
            const config = {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            };
            const res = await axios.post(
                `${import.meta.env.VITE_BASE_URL}/api/playlists/${playlistId}/add`,
                { song },
                config
            );
            return res.data;
        } catch (error) {
            return rejectWithValue(
                error.response && error.response.data.message
                    ? error.response.data.message
                    : error.message
            );
        }
    }
);

// Async thunk to delete a playlist
export const deletePlaylist = createAsyncThunk(
    "playlists/deletePlaylist",
    async (playlistId, { getState, rejectWithValue }) => {
        try {
            const { token } = getState().auth;
            const config = {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            };
            const res = await axios.delete(
                `${import.meta.env.VITE_BASE_URL}/api/playlists/${playlistId}`,
                config
            );
            return res.data;
        } catch (error) {
            return rejectWithValue(
                error.response && error.response.data.message
                    ? error.response.data.message
                    : error.message
            );
        }
    }
);

const playlistSlice = createSlice({
    name: "playlists",
    initialState,
    reducers: {
        clearPlaylistError: (state) => {
            state.error = null;
        },
    },
    extraReducers: (builder) => {
        builder
            // Fetch Playlists
            .addCase(fetchPlaylists.pending, (state) => {
                state.isLoading = true;
                state.error = null;
            })
            .addCase(fetchPlaylists.fulfilled, (state, action) => {
                state.isLoading = false;
                state.playlists = action.payload;
            })
            .addCase(fetchPlaylists.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.payload;
            })
            // Create Playlist
            .addCase(createPlaylist.fulfilled, (state, action) => {
                state.playlists.unshift(action.payload);
            })
            // Add Song
            .addCase(addSongToPlaylist.fulfilled, (state, action) => {
                const updatedPlaylist = action.payload;
                const index = state.playlists.findIndex((p) => p._id === updatedPlaylist._id);
                if (index !== -1) {
                    state.playlists[index] = updatedPlaylist;
                }
            })
            // Delete Playlist
            .addCase(deletePlaylist.fulfilled, (state, action) => {
                state.playlists = state.playlists.filter(
                    (p) => p._id !== action.payload.id
                );
            });
    },
});

export const { clearPlaylistError } = playlistSlice.actions;
export default playlistSlice.reducer;
